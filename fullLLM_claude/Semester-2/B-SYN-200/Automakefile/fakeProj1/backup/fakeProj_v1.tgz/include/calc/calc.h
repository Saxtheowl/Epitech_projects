int	toto(void)
