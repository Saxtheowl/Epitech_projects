
/*
** EPITECH PROJECT, 2025
** my_navy
** File description:
** Public header
*/
#ifndef NAVY_H_
#define NAVY_H_

#include <stdbool.h>
#include <signal.h>
#include <sys/types.h>
#include <stddef.h>

#define GRID 8
#define CELL_EMPTY '.'
#define CELL_HIT   'x'
#define CELL_MISS  'o'

typedef struct {
    char me[GRID][GRID];
    char enemy[GRID][GRID];
    int ships_total;
    int ships_hit;
} board_t;

/* global state for SIGUSR1/SIGUSR2 protocol (one justified global) */
typedef struct {
    volatile sig_atomic_t connected;
    volatile sig_atomic_t sync_mode;
    volatile sig_atomic_t count;
    volatile sig_atomic_t delim;
    volatile sig_atomic_t ack;
    volatile sig_atomic_t last_sig; /* 1 = USR1, 2 = USR2 */
    pid_t peer;
} sigstate_t;
extern sigstate_t GS;

int parse_map(const char *path, board_t *b);

/* io */
void put(const char *s);
void perr(const char *s);
void putnbr(long n);
void print_pid(void);
size_t slen(const char *s);
int scmp(const char *a, const char *b);

/* render */
void show_all(const board_t *b);

/* signals / link */
int setup_signals(void);
int wait_peer(void);         /* player 1 */
int connect_peer(pid_t p1);  /* player 2 */

/* protocol */
int send_num(int n);
int recv_num(void);
int send_coord(int col, int row);
int recv_coord(int *pc, int *pr);
int send_result(int hit);
int recv_result(void);

/* game */
int game_loop(bool p1_turn, board_t *b);

/* main API */
int run_p1(const char *map);
int run_p2(pid_t p1, const char *map);

#endif /* NAVY_H_ */
