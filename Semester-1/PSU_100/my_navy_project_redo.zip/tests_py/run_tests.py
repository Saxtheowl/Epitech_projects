
#!/usr/bin/env python3
# stdlib-only functional tests
import os, sys, subprocess, tempfile, time, re

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
BIN  = os.path.join(ROOT, "my_navy")

def run(args, input=None, timeout=3):
    p = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, stdin=subprocess.PIPE, text=True)
    out, err = p.communicate(input=input, timeout=timeout)
    return p.returncode, out, err

def assert_true(c, m):
    if not c: raise AssertionError(m)

def write_map(path, lines):
    with open(path,"w") as f: f.write("\n".join(lines)+"\n")

def t_help():
    rc, out, err = run([BIN, "-h"])
    assert_true(rc==0 and "USAGE" in out, "help ok")

def t_invalid_map():
    with tempfile.TemporaryDirectory() as d:
        bad = os.path.join(d,"bad.txt")
        write_map(bad, ["2:C1:C2","2:D4:F4","4:B5:B8","5:D7:H7"])
        rc, out, err = run([BIN, bad])
        assert_true(rc==84, "invalid navy -> 84")

def t_handshake():
    with tempfile.TemporaryDirectory() as d:
        m1 = os.path.join(d,"p1.txt"); m2 = os.path.join(d,"p2.txt")
        write_map(m1, ["2:C1:C2","3:D4:F4","4:B5:B8","5:D7:H7"])
        write_map(m2, ["2:C4:D4","3:H1:H3","4:E6:H6","5:B1:F1"])
        p1 = subprocess.Popen([BIN, m1], stdout=subprocess.PIPE, stderr=subprocess.PIPE, stdin=subprocess.PIPE, text=True)
        time.sleep(0.2)
        out1 = p1.stdout.readline()
        pidm = re.search(r"my_pid:\s*(\d+)", out1)
        assert_true(pidm, "p1 prints my_pid")
        pid = pidm.group(1)
        p2 = subprocess.Popen([BIN, pid, m2], stdout=subprocess.PIPE, stderr=subprocess.PIPE, stdin=subprocess.PIPE, text=True)
        # consume a few lines for connection
        _ = p2.stdout.readline()
        _ = p2.stdout.readline()
        _ = p1.stdout.readline()
        # do one attack then terminate
        # advance to 'attack:'
        for _ in range(40):
            s = p1.stdout.readline()
            if s.startswith("attack:"):
                break
        p1.stdin.write("B6\n"); p1.stdin.flush()
        time.sleep(0.4)
        p1.terminate(); p2.terminate()
        p1.wait(timeout=2); p2.wait(timeout=2)

def main():
    cases=[("help", t_help), ("invalid map", t_invalid_map), ("handshake", t_handshake)]
    ok=0
    print("Running tests...")
    for name,fn in cases:
        try:
            fn(); print("[OK]", name); ok+=1
        except Exception as e:
            print("[KO]", name, "-", e)
    print(f"\nResult: {ok}/{len(cases)} tests passed.")
    sys.exit(0 if ok==len(cases) else 84)

if __name__=="__main__":
    main()
