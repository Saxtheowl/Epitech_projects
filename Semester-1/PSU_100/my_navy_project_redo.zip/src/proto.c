
#include "navy.h"
#include <unistd.h>

static void pulse(int sig){ kill(GS.peer, sig); usleep(2000); }

int send_num(int n){
    if(n<1||n>8) return -1;
    GS.ack=0;
    for(int i=0;i<n;i++) pulse(SIGUSR1);
    pulse(SIGUSR2);
    while(!GS.ack) pause();
    return 0;
}
int recv_num(void){
    GS.sync_mode=1; GS.count=0; GS.delim=0;
    while(!GS.delim) pause();
    int n=(int)GS.count;
    kill(GS.peer, SIGUSR2); /* ack */
    GS.sync_mode=0; GS.count=0; GS.delim=0;
    if(n<1||n>8) return -1;
    return n;
}
int send_coord(int c,int r){ if(send_num(c)!=0) return -1; return send_num(r); }
int recv_coord(int *pc,int *pr){ int c=recv_num(); if(c<0) return -1; int r=recv_num(); if(r<0) return -1; *pc=c; *pr=r; return 0; }

int send_result(int hit){ if(hit){ pulse(SIGUSR1); pulse(SIGUSR1);} else { pulse(SIGUSR2);} return 0; }
int recv_result(void){ int u=0,z=0; for(;;){ pause(); if(GS.last_sig==1){ u++; if(u>=2) return 1; } if(GS.last_sig==2){ z++; if(z>=1) return 0; } } }
