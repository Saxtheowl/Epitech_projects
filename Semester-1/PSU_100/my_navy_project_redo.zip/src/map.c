
#include "navy.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static void bzero(board_t *b){
    for(int r=0;r<GRID;r++) for(int c=0;c<GRID;c++){ b->me[r][c]=CELL_EMPTY; b->enemy[r][c]=CELL_EMPTY; }
    b->ships_total=0; b->ships_hit=0;
}

static int place(board_t *b, int L, int c1, int r1, int c2, int r2){
    if(!(c1==c2 || r1==r2)) return -1;
    int dc = (c2>c1) ? 1 : (c2<c1 ? -1 : 0);
    int dr = (r2>r1) ? 1 : (r2<r1 ? -1 : 0);
    int cells = 1 + (c1==c2 ? (r2>r1?r2-r1:r1-r2) : (c2>c1?c2-c1:c1-c2));
    if(cells != L) return -1;
    for(int i=0, cc=c1, rr=r1; i<L; i++, cc+=dc, rr+=dr){
        if(b->me[rr][cc] != CELL_EMPTY) return -1;
        b->me[rr][cc] = (char)('0'+L);
    }
    b->ships_total += L;
    return 0;
}

int parse_map(const char *path, board_t *b){
    bzero(b);
    FILE *f = fopen(path, "r");
    if(!f){ perr("my_navy: cannot open positions file\n"); return -1; }
    char *line=NULL; size_t cap=0;
    int s2=0,s3=0,s4=0,s5=0, lines=0;
    while(1){
        ssize_t n = getline(&line,&cap,f);
        if(n<0) break;
        while(n>0 && (line[n-1]=='\n'||line[n-1]=='\r')) line[--n]=0;
        if(n==0) continue;
        lines++;
        if(n<7 || line[1]!=':' || line[4]!=':'){ perr("my_navy: invalid line format\n"); fclose(f); free(line); return -1; }
        int L = line[0]-'0';
        int c1=line[2]-'A', r1=line[3]-'1';
        int c2=line[5]-'A', r2=line[6]-'1';
        if(L<2||L>5 || c1<0||c1>=8||c2<0||c2>=8||r1<0||r1>=8||r2<0||r2>=8){ perr("my_navy: invalid coordinates\n"); fclose(f); free(line); return -1; }
        if(place(b,L,c1,r1,c2,r2)!=0){ perr("my_navy: invalid ship placement\n"); fclose(f); free(line); return -1; }
        if(L==2) s2++; if(L==3) s3++; if(L==4) s4++; if(L==5) s5++;
    }
    fclose(f); free(line);
    if(!(s2==1&&s3==1&&s4==1&&s5==1) || lines!=4){ perr("my_navy: invalid navy file (ship counts)\n"); return -1; }
    return 0;
}
