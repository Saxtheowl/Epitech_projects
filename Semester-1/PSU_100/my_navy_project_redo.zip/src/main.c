
#include "navy.h"
#include <stdlib.h>

static void help(void){
    put("USAGE\n");
    put("./my_navy [first_player_pid] navy_positions\n\n");
    put("DESCRIPTION\n");
    put("first_player_pid: only for the 2nd player. pid of the first player.\n");
    put("navy_positions: file representing the positions of the ships.\n");
}

int run_p1(const char *map){
    board_t b; if(parse_map(map,&b)!=0) return 84;
    if(setup_signals()!=0) return 84;
    print_pid(); if(wait_peer()!=0) return 84;
    return game_loop(true,&b);
}
int run_p2(pid_t p1,const char *map){
    board_t b; if(parse_map(map,&b)!=0) return 84;
    if(setup_signals()!=0) return 84;
    print_pid(); if(connect_peer(p1)!=0) return 84;
    return game_loop(false,&b);
}

int main(int ac, char **av){
    if(ac==2 && scmp(av[1], "-h")==0){ help(); return 0; }
    if(ac==2){ return run_p1(av[1]); }
    if(ac==3){
        long pid=0; for(char *p=av[1]; *p; ++p){ if(*p<'0'||*p>'9'){ perr("my_navy: bad pid\n"); return 84; } pid = pid*10 + (*p-'0'); }
        if(pid<=0) return 84;
        return run_p2((pid_t)pid, av[2]);
    }
    perr("my_navy: bad arguments\n"); return 84;
}
