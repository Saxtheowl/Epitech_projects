
#include "navy.h"
#include <stdio.h>
#include <stdlib.h>

static int is_ship(char ch){ return ch=='2'||ch=='3'||ch=='4'||ch=='5'; }

static void prompt(void){ put("attack: "); }

static int parse_coord(const char *s,int *pc,int *pr){
    if(!s||slen(s)<2) return -1;
    char C=s[0], R=s[1];
    if(C<'A'||C>'H'||R<'1'||R>'8') return -1;
    *pc = (C-'A')+1; *pr = (R-'1')+1;
    return 0;
}

static void mark_enemy(board_t *b,int c,int r,int hit){ b->enemy[r-1][c-1] = hit?CELL_HIT:CELL_MISS; }
static int apply_me(board_t *b,int c,int r){
    char *cell = &b->me[r-1][c-1];
    if(is_ship(*cell)){ *cell = CELL_HIT; b->ships_hit++; return 1; }
    if(*cell==CELL_EMPTY){ *cell = CELL_MISS; return 0; }
    return (*cell==CELL_HIT)?1:0;
}
static void print_result(int c,int r,int hit){
    char C='A'+(c-1); char R='1'+(r-1); char s[3]={C,R,0};
    put("result: "); put(s); put(hit?":hit\n":":missed\n");
}

static int is_finished(const board_t *b){ return b->ships_hit>=b->ships_total; }

int game_loop(bool p1_turn, board_t *b){
    char *line=NULL; size_t cap=0; int c,r;
    while(1){
        show_all(b);
        if(p1_turn){
            while(1){
                prompt();
                ssize_t n=getline(&line,&cap,stdin); if(n<0){ perr("my_navy: input error\n"); free(line); return 84; }
                while(n>0 && (line[n-1]=='\n'||line[n-1]=='\r')) line[--n]=0;
                if(parse_coord(line,&c,&r)!=0){ put("wrong position\n"); continue; }
                break;
            }
            if(send_coord(c,r)!=0){ free(line); return 84; }
            int hit=recv_result(); mark_enemy(b,c,r,hit); print_result(c,r,hit);
            if(hit && is_finished(b)){ put("\nI won\n"); free(line); return 0; }

            put("waiting for enemy's attack...\n");
            if(recv_coord(&c,&r)!=0){ free(line); return 84; }
            int ehit=apply_me(b,c,r); send_result(ehit); print_result(c,r,ehit);
        } else {
            put("waiting for enemy's attack...\n");
            if(recv_coord(&c,&r)!=0){ free(line); return 84; }
            int ehit=apply_me(b,c,r); send_result(ehit); print_result(c,r,ehit);
            if(is_finished(b)){ put("\nEnemy won\n"); free(line); return 1; }

            while(1){
                prompt();
                ssize_t n=getline(&line,&cap,stdin); if(n<0){ perr("my_navy: input error\n"); free(line); return 84; }
                while(n>0 && (line[n-1]=='\n'||line[n-1]=='\r')) line[--n]=0;
                if(parse_coord(line,&c,&r)!=0){ put("wrong position\n"); continue; }
                break;
            }
            if(send_coord(c,r)!=0){ free(line); return 84; }
            int hit=recv_result(); mark_enemy(b,c,r,hit); print_result(c,r,hit);
        }
        p1_turn = true;
    }
}
