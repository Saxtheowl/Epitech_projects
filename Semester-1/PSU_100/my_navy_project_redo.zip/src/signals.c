
#include "navy.h"
#include <string.h>
#include <unistd.h>

sigstate_t GS;

static void h1(int s, siginfo_t *si, void *u){ (void)s;(void)u; GS.last_sig=1; if(!GS.peer && si) GS.peer=si->si_pid; if(!GS.connected && si) GS.connected=1; if(GS.sync_mode) GS.count++; }
static void h2(int s, siginfo_t *si, void *u){ (void)s;(void)u; GS.last_sig=2; if(!GS.peer && si) GS.peer=si->si_pid; if(GS.sync_mode) GS.delim=1; else GS.ack=1; }

int setup_signals(void){
    memset(&GS,0,sizeof(GS));
    struct sigaction a; memset(&a,0,sizeof(a));
    a.sa_sigaction=h1; a.sa_flags=SA_SIGINFO; sigemptyset(&a.sa_mask);
    if(sigaction(SIGUSR1,&a,NULL)==-1) return -1;
    a.sa_sigaction=h2;
    if(sigaction(SIGUSR2,&a,NULL)==-1) return -1;
    return 0;
}

int wait_peer(void){
    put("waiting for enemy...\n");
    while(!GS.connected) pause();
    if(GS.peer<=0) return -1;
    kill(GS.peer, SIGUSR1); /* confirm */
    put("enemy connected\n");
    return 0;
}

int connect_peer(pid_t p1){
    if(p1<=0){ perr("my_navy: invalid pid\n"); return -1; }
    GS.peer = p1;
    if(kill(p1,SIGUSR1)==-1){ perr("my_navy: cannot contact first player\n"); return -1; }
    while(!GS.connected) pause(); /* wait confirm */
    put("successfully connected\n");
    return 0;
}
