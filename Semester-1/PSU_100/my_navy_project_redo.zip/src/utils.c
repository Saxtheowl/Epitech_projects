
#include "navy.h"
#include <unistd.h>
#include <stdlib.h>

size_t slen(const char *s){ size_t n=0; if(!s) return 0; while(s[n]) n++; return n; }
int scmp(const char *a, const char *b){
    size_t i=0; if(a==b) return 0; if(!a) return -1; if(!b) return 1;
    while(a[i] && b[i]){ unsigned char ca=a[i], cb=b[i]; if(ca!=cb) return (int)(ca-cb); i++; }
    if(a[i]) return 1; if(b[i]) return -1; return 0;
}
void put(const char *s){ if(s) write(1, s, slen(s)); }
void perr(const char *s){ if(s) write(2, s, slen(s)); }
void putnbr(long n){
    char buf[32]; int i=0; long x=n; if(n==0){ write(1,"0",1); return; }
    if(n<0){ write(1,"-",1); x=-n; }
    while(x>0){ buf[i++]=(char)('0'+(x%10)); x/=10; }
    for(int j=i-1;j>=0;j--) write(1,&buf[j],1);
}
void print_pid(void){ put("my_pid: "); putnbr((long)getpid()); put("\n"); }
