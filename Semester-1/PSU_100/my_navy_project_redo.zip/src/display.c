
#include "navy.h"

static void head(void){ put(" |A B C D E F G H\n"); put("-+---------------\n"); }
static void row(const char *r, int idx){
    putnbr(idx+1); put("|");
    for(int c=0;c<GRID;c++){ char ch=r[c]; char s[2]={ ch?ch:'.', 0}; put(s); if(c<GRID-1) put(" "); }
    put("\n");
}
void show_all(const board_t *b){
    put("my navy:\n"); head(); for(int r=0;r<GRID;r++) row(b->me[r], r);
    put("\nenemy navy:\n"); head(); for(int r=0;r<GRID;r++) row(b->enemy[r], r);
}
