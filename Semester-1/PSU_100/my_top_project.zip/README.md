
# my_top

Re-implémentation de `top` en mode ncurses (sans bonus), conforme au sujet : options `-U`, `-d`, `-n`, entête système, tableau des processus avec colonnes obligatoires (PID, USER, PR, NI, VIRT, RES, SHR, S, TIME, COMMAND), touches `E` (unités côté *process*) et **Shift+E** (unités côté *système*), flèches haut/bas pour scroller, `K` pour envoyer un signal (prompt simple), `q` pour quitter. Les valeurs CPU% et MEM% sont **SHOULD** dans le sujet → non implémentées volontairement. fileciteturn2file0

## Build
```bash
sudo apt-get install -y libncurses5-dev libncursesw5-dev
make
```

## Usage
```bash
./my_top -h
./my_top -U <username> -n 10 -d 1.5
./my_top -U <username>
```

## Détails d’implémentation
- Lecture depuis **procfs**: `/proc/loadavg`, `/proc/uptime`, `/proc/meminfo`, `/proc/[pid]/stat`, `/proc/[pid]/statm`, `/proc/[pid]/status`, `/proc/[pid]/comm`. Comptage des utilisateurs via `/var/run/utmp` (sans `getutent` interdit). Les fonctions interdites (`system`, `exec*`, `popen`, `getloadavg`, `getrusage`, `getrlimit`, `getutent`, `setutent`, …) ne sont **pas utilisées**. fileciteturn2file0
- Formatage **uptime** respecte les règles du sujet (jours seulement si ≥ 1, heures si > 0, sinon minutes, etc.). fileciteturn2file0
- Unit tests : les parseurs sont découplés de ncurses. Les chemins `/proc` et autres peuvent être **surchargés par variables d’env** (cf. header) pour utiliser des **fixtures**. fileciteturn2file0

## Tests
`make tests_run` exécute un mini-runner **Python stdlib** qui vérifie :  
- parsing d’uptime/loadavg/meminfo via fixtures,  
- formatage de l’uptime,  
- parsing `/etc/passwd` pour USER,  
- options `-U -d -n`.

## Limites
- Pas de CPU% / MEM% — *SHOULD* dans le sujet → exclu volontairement (non-bonus).  
- Le champ TIME est calculé à partir de `utime+stime` et `CLK_TCK` (approximation acceptable).  
- Le tri et autres commandes (htop-like) sont considérés bonus → non implémentés. fileciteturn2file0
