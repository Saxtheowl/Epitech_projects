
#!/usr/bin/env python3
# EPITECH PROJECT, 2025
# my_top - stdlib tests (no ncurses required)
import os, sys, tempfile, subprocess, textwrap, time

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
BIN  = os.path.join(ROOT, "my_top")

def run(args, env=None, timeout=2):
    p = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, stdin=subprocess.PIPE, text=True, env=env)
    try:
        out, err = p.communicate(timeout=timeout)
    except subprocess.TimeoutExpired:
        p.kill()
        out, err = p.communicate()
    return p.returncode, out, err

def assert_true(cond, msg):
    if not cond: raise AssertionError(msg)

def t_help():
    code, out, err = run([BIN, "-h"])
    assert_true(code == 0, "help exits 0")
    assert_true("usage" in out, "prints usage")

def t_options_parse_errors():
    code, out, err = run([BIN, "-d"])
    assert_true(code == 84, "bad args -> 84")

def t_format_uptime():
    # We test through a tiny helper binary? Simpler: just invoke my_top with -n 1 so it exits after one frame.
    # We can't easily inspect internal formatting, but at least smoke test runs and exits.
    code, out, err = run([BIN, "-n", "1"])
    assert_true(code == 0, "runs one frame and exits 0")

def main():
    cases = [
        ("help", t_help),
        ("bad args", t_options_parse_errors),
        ("one frame run", t_format_uptime),
    ]
    ok = 0
    print("Running tests...")
    for name, fn in cases:
        try:
            fn()
            print("[OK]", name)
            ok += 1
        except AssertionError as e:
            print("[KO]", name, "-", e)
        except Exception as e:
            print("[KO]", name, "- unexpected:", e)
    total = len(cases)
    print(f"\nResult: {ok}/{total} tests passed.")
    sys.exit(0 if ok == total else 84)

if __name__ == "__main__":
    main()
