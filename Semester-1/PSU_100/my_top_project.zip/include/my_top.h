
/*
** EPITECH PROJECT, 2025
** my_top
** File description:
** Public header
*/

#ifndef MY_TOP_H_
#define MY_TOP_H_

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <sys/types.h>

/* ===== Paths (overridable in tests via environment) ===== */
const char *path_proc(void);
const char *path_loadavg(void);
const char *path_uptime(void);
const char *path_meminfo(void);
const char *path_stat(void);
const char *path_swaps(void);
const char *path_passwd(void);
const char *path_utmp(void);

/* ===== Units ===== */
typedef enum {
    UNIT_KiB = 0,
    UNIT_MiB,
    UNIT_GiB,
    UNIT_TiB,
    UNIT_PiB,
    UNIT_EiB, /* only for system section per subject */
    UNIT_COUNT
} unit_t;

typedef struct {
    unit_t sys_unit;    /* Shift+E cycles system memory units */
    unit_t proc_unit;   /* E cycles per-process memory units */
    double delay_sec;   /* -d seconds (default 3.0) */
    long max_frames;    /* -n frames (default <0 unlimited) */
    char *filter_user;  /* -U username or NULL */
} options_t;

/* ===== System information ===== */
typedef struct {
    char time_of_day[64];
    char uptime_str[64];
    int users_logged;

    double loadavg[3];

    /* tasks */
    int tasks_total;
    int tasks_running;
    int tasks_sleeping;
    int tasks_stopped;
    int tasks_zombie;

    /* memory */
    uint64_t mem_total_kib;
    uint64_t mem_used_kib;
    uint64_t mem_free_kib;
    uint64_t mem_buffers_kib;
    uint64_t mem_cached_kib;

    /* swap */
    uint64_t swap_total_kib;
    uint64_t swap_used_kib;
    uint64_t swap_free_kib;
} sysinfo_t;

/* ===== Process information ===== */
typedef struct {
    int pid;
    uid_t uid;
    char user[32];
    long priority;   /* PR */
    long nice;       /* NI */
    uint64_t virt_kib;
    uint64_t res_kib;
    uint64_t shr_kib;
    char state;      /* R, S, T, Z, ... */
    uint64_t utime_ticks;
    uint64_t stime_ticks;
    uint64_t starttime_ticks;
    char comm[256];  /* COMMAND (basename) */
} procinfo_t;

typedef struct {
    procinfo_t *data;
    size_t size;
    size_t cap;
} vec_proc_t;

/* ===== API ===== */
int parse_options(int ac, char **av, options_t *out);
void options_free(options_t *o);

int fetch_system(sysinfo_t *out);
int fetch_processes(vec_proc_t *out, const options_t *opt);
void free_processes(vec_proc_t *v);

int user_name_from_uid(uid_t uid, char *dst, size_t dstsz);

void format_uptime(char *dst, size_t dstsz, double seconds);
uint64_t conv_to_unit(uint64_t kib, unit_t unit, double *value_out);

int run_ui_loop(const options_t *opt);

/* ===== Test-path helpers (env override names) ===== */
#define ENV_TOP_PROC     "MY_TOP_PROC"
#define ENV_TOP_LOADAVG  "MY_TOP_LOADAVG"
#define ENV_TOP_UPTIME   "MY_TOP_UPTIME"
#define ENV_TOP_MEMINFO  "MY_TOP_MEMINFO"
#define ENV_TOP_STAT     "MY_TOP_STAT"
#define ENV_TOP_SWAPS    "MY_TOP_SWAPS"
#define ENV_TOP_PASSWD   "MY_TOP_PASSWD"
#define ENV_TOP_UTMP     "MY_TOP_UTMP"

#endif /* !MY_TOP_H_ */
