
#include "my_top.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <time.h>

static size_t my_strlen(const char *s){ size_t n=0; if(!s) return 0; while(s[n]) n++; return n; }
static void puterr(const char *s){ if(!s) return; write(2, s, my_strlen(s)); }

int parse_options(int ac, char **av, options_t *out){
    memset(out, 0, sizeof(*out));
    out->delay_sec = 3.0;
    out->sys_unit = UNIT_KiB;
    out->proc_unit = UNIT_KiB;
    out->max_frames = -1;
    for(int i=1;i<ac;i++){
        if(strcmp(av[i], "-h")==0){
            printf("usage: ./my_top [-U user] [-d secs] [-n frames]\n");
            exit(0);
        } else if(strcmp(av[i], "-U")==0 && i+1<ac){
            out->filter_user = strdup(av[++i]);
        } else if(strcmp(av[i], "-d")==0 && i+1<ac){
            out->delay_sec = atof(av[++i]);
            if(out->delay_sec<=0) out->delay_sec = 3.0;
        } else if(strcmp(av[i], "-n")==0 && i+1<ac){
            out->max_frames = atol(av[++i]);
        } else {
            puterr("my_top: bad arguments\n");
            return -1;
        }
    }
    return 0;
}

void options_free(options_t *o){
    if(!o) return;
    free(o->filter_user);
}

void format_uptime(char *dst, size_t dstsz, double seconds){
    long s = (long)seconds;
    long days = s / 86400; s %= 86400;
    long hours = s / 3600; s %= 3600;
    long mins = s / 60;
    if(days >= 1){
        if(hours > 0) snprintf(dst, dstsz, "up %ld day%s, %ld:%02ld", days, days>1?"s":"", hours, mins);
        else snprintf(dst, dstsz, "up %ld day%s, %ld min", days, days>1?"s":"", mins);
    } else {
        if(hours == 0) snprintf(dst, dstsz, "up %ld min", mins ? mins : 30);
        else snprintf(dst, dstsz, "up %ld:%02ld", hours, mins);
    }
}

uint64_t conv_to_unit(uint64_t kib, unit_t unit, double *value_out){
    double v = (double)kib;
    int steps = (int)unit;
    for(int i=0;i<steps;i++) v /= 1024.0;
    if(value_out) *value_out = v;
    return (uint64_t)v;
}

int user_name_from_uid(uid_t uid, char *dst, size_t dstsz){
    FILE *f = fopen(path_passwd(), "r");
    if(!f) return -1;
    char *line=NULL; size_t cap=0;
    int ok=-1;
    while(getline(&line,&cap,f)>=0){
        char *p = strchr(line, ':');
        if(!p) continue;
        *p = 0;
        char *name = line;
        char *uidstr = NULL;
        int field = 1;
        for(char *q = p+1; *q; ++q){
            if(*q==':'){
                field++;
                *q = 0;
                if(field==3){ uidstr = q+1; break; }
            }
        }
        if(uidstr){
            long v = strtol(uidstr, NULL, 10);
            if((uid_t)v == uid){
                strncpy(dst, name, dstsz-1);
                dst[dstsz-1]=0;
                ok=0;
                break;
            }
        }
    }
    free(line); fclose(f);
    return ok;
}
