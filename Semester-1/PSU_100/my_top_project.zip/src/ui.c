
#include "my_top.h"
#include <curses.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <signal.h>

sysinfo_t g_last_sys; /* shared with fetch_processes to fill tasks counters */

static void draw_header(const sysinfo_t *s, unit_t sys_unit){
    move(0,0); clrtoeol();
    printw("top - %s up %s,  %d user%s,  load average: %.2f, %.2f, %.2f",
        s->time_of_day, s->uptime_str, s->users_logged, s->users_logged>1?"s":"",
        s->loadavg[0], s->loadavg[1], s->loadavg[2]);

    move(1,0); clrtoeol();
    printw("Tasks: %d total, %d running, %d sleeping, %d stopped, %d zombie",
        s->tasks_total, s->tasks_running, s->tasks_sleeping, s->tasks_stopped, s->tasks_zombie);

    /* Memory */
    double mt, mu, mf, swt, swu, swf;
    conv_to_unit(s->mem_total_kib, sys_unit, &mt);
    conv_to_unit(s->mem_used_kib, sys_unit, &mu);
    conv_to_unit(s->mem_free_kib, sys_unit, &mf);
    conv_to_unit(s->swap_total_kib, sys_unit, &swt);
    conv_to_unit(s->swap_used_kib, sys_unit, &swu);
    conv_to_unit(s->swap_free_kib, sys_unit, &swf);

    const char *unit_strs[] = {"KiB","MiB","GiB","TiB","PiB","EiB"};
    const char *u = unit_strs[sys_unit];

    move(2,0); clrtoeol();
    printw("Mem : %5.0f %s total, %5.0f used, %5.0f free, %5.0f buffers, %5.0f cached",
        mt, u, mu, mf, (double)s->mem_buffers_kib/(1<<(10*sys_unit)), (double)s->mem_cached_kib/(1<<(10*sys_unit)));
    move(3,0); clrtoeol();
    printw("Swap: %5.0f %s total, %5.0f used, %5.0f free",
        swt, u, swu, swf);
}

static void draw_table_header(void){
    move(5,0); clrtoeol();
    printw("  PID USER       PR  NI   VIRT    RES    SHR S   TIME+   COMMAND");
}

static void draw_process_row(int row, const procinfo_t *p, unit_t proc_unit){
    double v,res,shr;
    conv_to_unit(p->virt_kib, proc_unit, &v);
    conv_to_unit(p->res_kib, proc_unit, &res);
    conv_to_unit(p->shr_kib, proc_unit, &shr);
    const char *unit_strs[] = {"K","M","G","T","P","E"};
    const char *u = unit_strs[proc_unit];

    /* Simplified TIME+: show utime+stime in seconds based on sysconf CLK_TCK */
    long ticks = sysconf(_SC_CLK_TCK);
    unsigned long long ttotal = p->utime_ticks + p->stime_ticks;
    unsigned long sec = (unsigned long)(ttotal / (unsigned long long)ticks);
    unsigned long min = sec / 60; sec %= 60;

    move(row, 0); clrtoeol();
    printw("%5d %-10.10s %3ld %3ld %6.0f%s %6.0f%s %6.0f%s %c %3lu:%02lu %-s",
        p->pid, p->user, p->priority, p->nice,
        v, u, res, u, shr, u, p->state, min, sec, p->comm);
}

int run_ui_loop(const options_t *opt){
    initscr();
    noecho();
    cbreak();
    keypad(stdscr, TRUE);
    nodelay(stdscr, FALSE);
    curs_set(0);

    int scroll = 0;
    unit_t sys_unit = opt->sys_unit;
    unit_t proc_unit = opt->proc_unit;

    long frame = 0;
    while(opt->max_frames < 0 || frame < opt->max_frames){
        sysinfo_t s;
        if(fetch_system(&s)!=0){ endwin(); fprintf(stderr,"my_top: cannot fetch system\n"); return 84; }
        g_last_sys = s;
        vec_proc_t v;
        if(fetch_processes(&v, opt)!=0){ endwin(); fprintf(stderr,"my_top: cannot fetch processes\n"); return 84; }

        erase();
        draw_header(&s, sys_unit);
        draw_table_header();
        int H,W; getmaxyx(stdscr,H,W);
        int maxrows = H - 6;
        if(scroll < 0) scroll = 0;
        if(scroll > (int)v.size - maxrows) scroll = (int)v.size - maxrows;
        if(scroll < 0) scroll = 0;
        for(int i=0;i<maxrows && (size_t)(i+scroll)<v.size;i++){
            draw_process_row(6+i, &v.data[i+scroll], proc_unit);
        }
        refresh();

        /* wait with timeout; handle keys */
        timeout((int)(opt->delay_sec * 1000));
        int ch = getch();
        if(ch == KEY_UP){ scroll--; if(scroll<0) scroll=0; }
        else if(ch == KEY_DOWN){ scroll++; }
        else if(ch == 'E'){ /* per-process units */
            proc_unit = (proc_unit + 1) % UNIT_COUNT;
            if(proc_unit > UNIT_EiB) proc_unit = UNIT_KiB; /* proc doesn't use EiB realistically */
        } else if(ch == 'e'){ /* system units */
            sys_unit = (sys_unit + 1) % UNIT_COUNT;
        } else if(ch == 'K'){ /* send signal prompt (best-effort) */
            echo();
            timeout(-1);
            mvprintw(4,0,"Send signal (default 15) to PID (default top row): ");
            char buf[64]; getnstr(buf, 63);
            int sig = 15; int pid = 0;
            sscanf(buf, "%d %d", &sig, &pid);
            if(pid==0 && v.size>0) pid = v.data[scroll].pid;
            if(pid>0) kill(pid, sig);
            noecho();
        } else if(ch == 'q' || ch== 'Q'){ free_processes(&v); break; }

        free_processes(&v);
        frame++;
    }

    endwin();
    return 0;
}
