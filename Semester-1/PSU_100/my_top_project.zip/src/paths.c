
#include <stdlib.h>
#include "my_top.h"

static const char *getenv_or(const char *name, const char *fallback){
    const char *v = getenv(name);
    return v ? v : fallback;
}

const char *path_proc(void)    { return getenv_or(ENV_TOP_PROC,    "/proc"); }
const char *path_loadavg(void) { return getenv_or(ENV_TOP_LOADAVG, "/proc/loadavg"); }
const char *path_uptime(void)  { return getenv_or(ENV_TOP_UPTIME,  "/proc/uptime"); }
const char *path_meminfo(void) { return getenv_or(ENV_TOP_MEMINFO, "/proc/meminfo"); }
const char *path_stat(void)    { return getenv_or(ENV_TOP_STAT,    "/proc/stat"); }
const char *path_swaps(void)   { return getenv_or(ENV_TOP_SWAPS,   "/proc/swaps"); }
const char *path_passwd(void)  { return getenv_or(ENV_TOP_PASSWD,  "/etc/passwd"); }
const char *path_utmp(void)    { return getenv_or(ENV_TOP_UTMP,    "/var/run/utmp"); }
