
#include "my_top.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <utmp.h>
#include <fcntl.h>
#include <unistd.h>

static int count_logged_users(void){
    int fd = open(path_utmp(), O_RDONLY);
    if(fd<0) return 0;
    struct utmp rec;
    int count = 0;
    while(read(fd, &rec, sizeof(rec)) == sizeof(rec)){
        if(rec.ut_type == USER_PROCESS) count++;
    }
    close(fd);
    return count;
}

int fetch_system(sysinfo_t *out){
    memset(out, 0, sizeof(*out));
    /* time of day */
    time_t now = time(NULL);
    struct tm tmv;
    localtime_r(&now, &tmv);
    strftime(out->time_of_day, sizeof(out->time_of_day), "%H:%M:%S", &tmv);

    /* uptime */
    FILE *fu = fopen(path_uptime(), "r");
    if(!fu) return -1;
    double up=0.0, idle=0.0;
    fscanf(fu, "%lf %lf", &up, &idle);
    fclose(fu);
    format_uptime(out->uptime_str, sizeof(out->uptime_str), up);

    out->users_logged = count_logged_users();

    /* loadavg */
    FILE *fl = fopen(path_loadavg(), "r");
    if(!fl) return -1;
    fscanf(fl, "%lf %lf %lf", &out->loadavg[0], &out->loadavg[1], &out->loadavg[2]);
    fclose(fl);

    /* meminfo */
    FILE *fm = fopen(path_meminfo(), "r");
    if(!fm) return -1;
    char key[64]; unsigned long long val; char unit[8];
    unsigned long long mem_total=0, mem_free=0, buffers=0, cached=0, sreclaimable=0;
    unsigned long long swap_total=0, swap_free=0;
    while(fscanf(fm, "%63s %llu %7s", key, &val, unit)==3){
        if(strcmp(key,"MemTotal:")==0) mem_total = val;
        else if(strcmp(key,"MemFree:")==0) mem_free = val;
        else if(strcmp(key,"Buffers:")==0) buffers = val;
        else if(strcmp(key,"Cached:")==0) cached = val;
        else if(strcmp(key,"SReclaimable:")==0) sreclaimable = val;
        else if(strcmp(key,"SwapTotal:")==0) swap_total = val;
        else if(strcmp(key,"SwapFree:")==0) swap_free = val;
    }
    fclose(fm);
    out->mem_total_kib = mem_total;
    unsigned long long used = mem_total - mem_free - buffers - cached - sreclaimable;
    if((long long)used < 0) used = 0;
    out->mem_used_kib = used;
    out->mem_free_kib = mem_free;
    out->mem_buffers_kib = buffers;
    out->mem_cached_kib = cached;

    out->swap_total_kib = swap_total;
    out->swap_free_kib = swap_free;
    out->swap_used_kib = (swap_total>swap_free) ? (swap_total - swap_free) : 0;

    /* tasks counters will be filled by fetch_processes */
    return 0;
}
