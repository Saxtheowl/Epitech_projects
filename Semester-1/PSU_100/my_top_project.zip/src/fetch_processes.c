
#define _GNU_SOURCE
#include "my_top.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <ctype.h>
#include <unistd.h>

static void vp_push(vec_proc_t *v, const procinfo_t *p){
    if(v->size==v->cap){
        size_t ncap = v->cap ? v->cap*2 : 256;
        procinfo_t *nd = realloc(v->data, ncap*sizeof(procinfo_t));
        if(!nd) return;
        v->data = nd; v->cap = ncap;
    }
    v->data[v->size++] = *p;
}

void free_processes(vec_proc_t *v){
    if(!v) return;
    free(v->data); memset(v, 0, sizeof(*v));
}

static int read_cmd_comm(int pid, char *comm, size_t cmsz){
    char path[256];
    snprintf(path, sizeof(path), "%s/%d/comm", path_proc(), pid);
    FILE *f = fopen(path, "r");
    if(f){
        if(fgets(comm, (int)cmsz, f)){
            size_t n=strlen(comm); if(n>0 && comm[n-1]=='\n') comm[n-1]=0;
        } else strncpy(comm, "?", cmsz);
        fclose(f);
        return 0;
    }
    strncpy(comm, "?", cmsz);
    return -1;
}

static int read_status_uid(int pid, uid_t *uid){
    char path[256]; snprintf(path,sizeof(path), "%s/%d/status", path_proc(), pid);
    FILE *f = fopen(path, "r"); if(!f) return -1;
    char key[64], val[256];
    int ok=-1;
    while(fscanf(f,"%63s %255s", key, val)==2){
        if(strcmp(key,"Uid:")==0){
            *uid = (uid_t)strtol(val, NULL, 10); ok=0; break;
        }
    }
    fclose(f); return ok;
}

static int read_statm(int pid, uint64_t *virt_kib, uint64_t *res_kib, uint64_t *shr_kib){
    char path[256]; snprintf(path,sizeof(path), "%s/%d/statm", path_proc(), pid);
    FILE *f = fopen(path, "r"); if(!f) return -1;
    unsigned long v=0,r=0,s=0;
    if(fscanf(f, "%lu %lu %lu", &v,&r,&s)!=3){ fclose(f); return -1; }
    fclose(f);
    long page_kb = sysconf(_SC_PAGESIZE) / 1024;
    *virt_kib = (uint64_t)v * (uint64_t)page_kb;
    *res_kib  = (uint64_t)r * (uint64_t)page_kb;
    *shr_kib  = (uint64_t)s * (uint64_t)page_kb;
    return 0;
}

static int read_stat_core(int pid, char *state, long *prio, long *nicev, uint64_t *ut, uint64_t *st, uint64_t *startt){
    char path[256]; snprintf(path,sizeof(path), "%s/%d/stat", path_proc(), pid);
    FILE *f = fopen(path, "r"); if(!f) return -1;
    /* fields: pid (1) comm (2) state (3) ... utime(14) stime(15) priority(18) nice(19) starttime(22) */
    int pidv; char commbuf[256]; char st;
    unsigned long long utime=0, stime=0, starttime=0;
    long pr=0, ni=0;
    /* Read the entire line because comm can contain spaces in parentheses */
    char line[4096];
    if(!fgets(line, sizeof(line), f)){ fclose(f); return -1; }
    fclose(f);
    /* parse */
    char *lp = strchr(line, '(');
    char *rp = strrchr(line, ')');
    if(!lp || !rp) return -1;
    *rp = 0;
    strncpy(commbuf, lp+1, sizeof(commbuf)-1); commbuf[sizeof(commbuf)-1]=0;
    /* state char after ) and space */
    char *p = rp + 2;
    st = *p;
    /* tokenize after state */
    /* Move to field 14 (utime) */
    int field = 3;
    while(*p && field < 14){
        if(*p==' ') field++;
        p++;
    }
    if(field != 14) return -1;
    utime = strtoull(p, &p, 10);
    stime = strtoull(p, &p, 10);
    /* skip cutime, cstime */
    for(int k=0;k<2;k++) strtoull(p, &p, 10);
    pr = strtol(p, &p, 10);
    ni = strtol(p, &p, 10);
    /* skip num_threads, itrealvalue */
    for(int k=0;k<2;k++) strtol(p, &p, 10);
    starttime = strtoull(p, &p, 10);

    *state = st;
    *prio = pr;
    *nicev = ni;
    *ut = utime;
    *st = stime;
    *startt = starttime;
    return 0;
}

int fetch_processes(vec_proc_t *out, const options_t *opt){
    memset(out, 0, sizeof(*out));
    DIR *d = opendir(path_proc());
    if(!d) return -1;
    struct dirent *de;
    int total=0, run=0, sleep=0, stop=0, zomb=0;
    while((de = readdir(d))){
        if(!isdigit((unsigned char)de->d_name[0])) continue;
        int pid = atoi(de->d_name);
        procinfo_t pi; memset(&pi, 0, sizeof(pi));
        pi.pid = pid;
        if(read_status_uid(pid, &pi.uid)!=0) continue;
        if(user_name_from_uid(pi.uid, pi.user, sizeof(pi.user))!=0) strncpy(pi.user, "?", sizeof(pi.user));
        read_cmd_comm(pid, pi.comm, sizeof(pi.comm));
        read_statm(pid, &pi.virt_kib, &pi.res_kib, &pi.shr_kib);
        read_stat_core(pid, &pi.state, &pi.priority, &pi.nice, &pi.utime_ticks, &pi.stime_ticks, &pi.starttime_ticks);

        /* filter */
        if(opt && opt->filter_user && strcmp(opt->filter_user, pi.user)!=0) {
            /* still count tasks for system section */
        } else {
            vp_push(out, &pi);
        }

        total++;
        switch(pi.state){
            case 'R': run++; break;
            case 'S': sleep++; break;
            case 'D': sleep++; break;
            case 'T': stop++; break;
            case 't': stop++; break;
            case 'Z': zomb++; break;
            default: sleep++; break;
        }
    }
    closedir(d);
    /* Store task counters in a global static last_sys? Rather return via fetch_system? We'll expose as static and accessible */
    extern sysinfo_t g_last_sys;
    g_last_sys.tasks_total = total;
    g_last_sys.tasks_running = run;
    g_last_sys.tasks_sleeping = sleep;
    g_last_sys.tasks_stopped = stop;
    g_last_sys.tasks_zombie = zomb;
    return 0;
}
