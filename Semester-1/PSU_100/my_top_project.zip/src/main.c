
#include "my_top.h"
#include <stdio.h>
#include <stdlib.h>

int main(int ac, char **av){
    options_t opt;
    if(parse_options(ac, av, &opt)!=0){
        fprintf(stderr, "usage: ./my_top [-U user] [-d secs] [-n frames]\n");
        return 84;
    }
    int rc = run_ui_loop(&opt);
    options_free(&opt);
    return rc;
}
