
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "my_sudo.h"

static int line_authorizes(const user_info_t *u, const char *line){
    const char *p=line; while(*p==' '||*p=='\t') p++; if(!*p) return 0;
    char tok[128]={0}; int i=0; while(*p && *p!=' ' && *p!='\t' && *p!='\r' && *p!='\n' && i<120){ tok[i++]=*p++; } tok[i]=0;
    if(!tok[0]) return 0;
    if(tok[0]=='%'){ if(tok[1]=='#'){ int ok=0; long v=parse_long(tok+1,&ok); return ok && user_in_groupgid(u->username,(gid_t)v); }
        else return user_in_groupname(u->username, tok+1);
    } else if(tok[0]=='#'){ int ok=0; long v=parse_long(tok,&ok); return ok && (uid_t)v==u->uid;
    } else { return scmp(tok, u->username)==0; }
}

int is_authorized_in_sudoers(const user_info_t *u){
    FILE *f=fopen(path_sudoers(),"r"); if(!f){ puterr("my_sudo: cannot open /etc/sudoers\n"); return 0; }
    char *line=NULL; size_t cap=0; int auth=0;
    while(getline(&line,&cap,f)>=0){ char *t=trim(line); if(!t[0]) continue; if(line_authorizes(u,t)){ auth=1; break; } }
    free(line); fclose(f); return auth;
}
