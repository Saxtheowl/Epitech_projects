
#define _GNU_SOURCE
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include "my_sudo.h"

static char *dup_shell_for_user(const char *username){
    FILE *f=fopen(path_passwd(),"r"); if(!f) return NULL;
    char *line=NULL; size_t cap=0; char *ret=NULL;
    while(getline(&line,&cap,f)>=0){ char *t=trim(line); if(!t[0]) continue;
        char *tmp=xstrdup(t); char *name=strtok(tmp,":");
        if(name && scmp(name,username)==0){
            strtok(NULL,":"); strtok(NULL,":"); strtok(NULL,":"); strtok(NULL,":"); strtok(NULL,":");
            char *shell=strtok(NULL,":"); if(shell) ret=xstrdup(shell); free(tmp); break; } free(tmp); }
    free(line); fclose(f); return ret;
}

static int setup_env(const options_t *opts, const user_info_t *tgt){
    if(!opts->keep_env){ clearenv(); setenv("PATH","/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",1); }
    char uidbuf[32]; snprintf(uidbuf,sizeof(uidbuf),"%ld",(long)tgt->uid);
    char gidbuf[32]; snprintf(gidbuf,sizeof(gidbuf),"%ld",(long)tgt->gid);
    setenv("SUDO_UID", uidbuf, 1); setenv("SUDO_GID", gidbuf, 1); setenv("SUDO_USER", tgt->username, 1);
    setenv("USER", tgt->username, 1); setenv("LOGNAME", tgt->username, 1);
    return 0;
}

int run_sudo(const user_info_t *invoker, const options_t *opts){
    if(!is_authorized_in_sudoers(invoker)){ puterr("user is not in the my_sudoers file.\n"); return 84; }
    int failed=0; if(authenticate_user(invoker->username,&failed)!=0){ puterr("my_sudo: authentication failed\n"); return 84; }
    user_info_t tgt_user={0}; gid_t tgt_gid=invoker->gid;
    if(opts->target_user){ if(resolve_user(opts->target_user,&tgt_user)!=0) return 84; }
    else { if(read_user_by_uid(0,&tgt_user)!=0) return 84; }
    if(opts->target_group){ if(resolve_group(opts->target_group,&tgt_gid)!=0){ free_user(&tgt_user); return 84; } }
    else { tgt_gid=tgt_user.gid; }
    if(setgid(tgt_gid)!=0){ puterr("my_sudo: setgid failed\n"); free_user(&tgt_user); return 84; }
    if(setuid(tgt_user.uid)!=0){ puterr("my_sudo: setuid failed\n"); free_user(&tgt_user); return 84; }
    setup_env(opts,&tgt_user);
    if(opts->shell_mode){
        const char *env_shell=getenv("SHELL"); char *shell_path=NULL;
        if(opts->target_user){ shell_path=dup_shell_for_user(tgt_user.username); }
        else if(env_shell && opts->keep_env){ shell_path=xstrdup(env_shell); }
        else { shell_path=dup_shell_for_user(tgt_user.username); }
        if(!shell_path){ puterr("my_sudo: cannot determine shell\n"); free_user(&tgt_user); return 84; }
        char *argvv[2]={ shell_path, NULL }; execvp(shell_path, argvv); puterr("my_sudo: exec shell failed\n"); free(shell_path); free_user(&tgt_user); return 84;
    } else {
        if(!opts->cmdv || !opts->cmdv[0]){ puterr("my_sudo: no command provided\n"); free_user(&tgt_user); return 84; }
        execvp(opts->cmdv[0], opts->cmdv); puterr("my_sudo: exec failed\n"); free_user(&tgt_user); return 84;
    }
}
