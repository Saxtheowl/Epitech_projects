
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "my_sudo.h"

size_t slen(const char *s){ size_t n=0; if(!s) return 0; while(s[n]) n++; return n; }
int scmp(const char *a, const char *b){
    size_t i=0; if(a==b) return 0; if(!a) return -1; if(!b) return 1;
    while(a[i] && b[i]){ unsigned char ca=a[i], cb=b[i]; if(ca!=cb) return (int)(ca-cb); i++; }
    if(a[i]) return 1; if(b[i]) return -1; return 0;
}
void putstr(const char *s){ if(s) write(1, s, slen(s)); }
void puterr(const char *s){ if(s) write(2, s, slen(s)); }
void *xmalloc(size_t n){ void *p = malloc(n); if(!p){ puterr("my_sudo: malloc failed\n"); exit(84);} return p; }
char *xstrdup(const char *s){ size_t n = slen(s); char *p = xmalloc(n+1); for(size_t i=0;i<n;i++) p[i]=s[i]; p[n]=0; return p; }
char *trim(char *s){
    if(!s) return s; size_t n = slen(s); size_t i=0, j=n;
    while(i<n && (s[i]==' '||s[i]=='\t'||s[i]=='\r'||s[i]=='\n')) i++;
    while(j>i && (s[j-1]==' '||s[j-1]=='\t'||s[j-1]=='\r'||s[j-1]=='\n')) j--;
    if(i>0) memmove(s, s+i, j-i); s[j-i]=0; return s;
}
long parse_long(const char *s, int *ok){
    long v=0; int sign=1; size_t i=0; if(ok) *ok=0; if(!s||!s[0]) return 0; if(s[0]=='#') i++;
    if(s[i]=='+'){ i++; } else if(s[i]=='-'){ sign=-1; i++; }
    int any=0; for(; s[i]; i++){ if(s[i]<'0'||s[i]>'9') return 0; any=1; v = v*10 + (s[i]-'0'); }
    if(!any) return 0; if(ok) *ok=1; return v*sign;
}
const char *path_passwd(void){ const char *e=getenv("MY_SUDO_PASSWD"); return e?e:"/etc/passwd"; }
const char *path_shadow(void){ const char *e=getenv("MY_SUDO_SHADOW"); return e?e:"/etc/shadow"; }
const char *path_group(void){ const char *e=getenv("MY_SUDO_GROUP"); return e?e:"/etc/group"; }
const char *path_sudoers(void){ const char *e=getenv("MY_SUDO_SUDOERS"); return e?e:"/etc/sudoers"; }
void free_user(user_info_t *u){ if(!u) return; free(u->username); memset(u,0,sizeof(*u)); }
