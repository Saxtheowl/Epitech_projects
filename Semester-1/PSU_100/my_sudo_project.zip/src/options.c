
#include <string.h>
#include <stdlib.h>
#include "my_sudo.h"

static void print_help(void){
    putstr("usage: ./my_sudo -h\n\n");
    putstr("usage: ./my_sudo [-ugEs] [command [args ...]]\n");
}

int parse_options(int ac, char **av, options_t *opts){
    memset(opts,0,sizeof(*opts)); int i=1;
    if(ac==2 && scmp(av[1],"-h")==0){ print_help(); exit(0); }
    for(; i<ac; ++i){
        if(av[i][0]!='-') break;
        if(scmp(av[i],"-u")==0){ if(i+1>=ac){ puterr("my_sudo: -u requires an argument\n"); return -1;} opts->target_user=av[++i]; }
        else if(scmp(av[i],"-g")==0){ if(i+1>=ac){ puterr("my_sudo: -g requires an argument\n"); return -1;} opts->target_group=av[++i]; }
        else if(scmp(av[i],"-E")==0){ opts->keep_env=true; }
        else if(scmp(av[i],"-s")==0){ opts->shell_mode=true; }
        else { break; }
    }
    opts->cmdv = (i<ac) ? &av[i] : NULL;
    return 0;
}
