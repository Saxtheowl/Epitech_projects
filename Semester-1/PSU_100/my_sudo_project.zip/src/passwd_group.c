
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "my_sudo.h"

static int split_fields(char *line, char **out, int cap){
    int n=0; char *p=line; while(n<cap){ out[n++]=p; char *c=strchr(p,':'); if(!c) break; *c=0; p=c+1; } return n;
}

int read_current_user(user_info_t *out){ uid_t uid=getuid(); return read_user_by_uid(uid,out); }

int read_user_by_uid(uid_t uid, user_info_t *out){
    FILE *f=fopen(path_passwd(),"r"); if(!f){ puterr("my_sudo: cannot open /etc/passwd\n"); return -1; }
    char *line=NULL; size_t cap=0; int ok=-1;
    while(getline(&line,&cap,f)>=0){
        trim(line); if(!line[0]) continue; char *tmp=xstrdup(line);
        char *fld[7]={0}; int nf=split_fields(tmp,fld,7);
        if(nf>=7){ int good=0; long v=parse_long(fld[2],&good);
            if(good && (uid_t)v==uid){ out->username=xstrdup(fld[0]); out->uid=(uid_t)v;
                long gv=parse_long(fld[3],&good); out->gid=good?(gid_t)gv:(gid_t)v; ok=0; free(tmp); break; } }
        free(tmp);
    }
    free(line); fclose(f); if(ok!=0) puterr("my_sudo: cannot resolve current user\n"); return ok;
}

int read_user_by_name(const char *name, user_info_t *out){
    FILE *f=fopen(path_passwd(),"r"); if(!f){ puterr("my_sudo: cannot open /etc/passwd\n"); return -1; }
    char *line=NULL; size_t cap=0; int ok=-1;
    while(getline(&line,&cap,f)>=0){
        trim(line); if(!line[0]) continue; char *tmp=xstrdup(line);
        char *fld[7]={0}; int nf=split_fields(tmp,fld,7);
        if(nf>=7 && scmp(fld[0],name)==0){ int good=0; long uv=parse_long(fld[2],&good); out->username=xstrdup(fld[0]); out->uid=good?(uid_t)uv:0;
            long gv=parse_long(fld[3],&good); out->gid=good?(gid_t)gv:0; ok=0; free(tmp); break; }
        free(tmp);
    }
    free(line); fclose(f); if(ok!=0) puterr("my_sudo: user not found\n"); return ok;
}

int resolve_user(const char *name_or_num, user_info_t *out){ int ok=0; long v=parse_long(name_or_num,&ok); return ok?read_user_by_uid((uid_t)v,out):read_user_by_name(name_or_num,out); }

static int group_line_has_user(const char *line, const char *user){
    const char *p=strchr(line,':'); if(!p) return 0; p=strchr(p+1,':'); if(!p) return 0; p=strchr(p+1,':'); if(!p) return 0; p++;
    size_t ulen=slen(user); const char *q=p;
    while(*q){ const char *comma=strchr(q,','); size_t len=comma?(size_t)(comma-q):slen(q);
        if(len==ulen && strncmp(q,user,len)==0) return 1; if(!comma) break; q=comma+1; } return 0;
}

int resolve_group(const char *name_or_num, gid_t *out_gid){
    int ok=0; long v=parse_long(name_or_num,&ok); if(ok){ *out_gid=(gid_t)v; return 0; }
    FILE *f=fopen(path_group(),"r"); if(!f){ puterr("my_sudo: cannot open /etc/group\n"); return -1; }
    char *line=NULL; size_t cap=0; int rc=-1;
    while(getline(&line,&cap,f)>=0){ trim(line); if(!line[0]) continue; char *tmp=xstrdup(line);
        char *c1=strchr(tmp,':'); if(!c1){ free(tmp); continue; } *c1=0;
        if(scmp(tmp,name_or_num)==0){ char *c2=c1+1; c2=strchr(c2,':'); if(c2){ c2++; char *gidstr=c2; char *c3=strchr(c2,':'); if(c3) *c3=0; int good=0; long gv=parse_long(gidstr,&good); if(good){ *out_gid=(gid_t)gv; rc=0; free(tmp); break; } } }
        free(tmp);
    }
    free(line); fclose(f); if(rc!=0) puterr("my_sudo: group not found\n"); return rc;
}

int user_in_groupname(const char *username, const char *groupname){
    FILE *f=fopen(path_group(),"r"); if(!f) return 0; char *line=NULL; size_t cap=0; int ok=0;
    while(getline(&line,&cap,f)>=0){ trim(line); if(!line[0]) continue; char *tmp=xstrdup(line); char *c=strchr(tmp,':'); if(!c){ free(tmp); continue; } *c=0;
        if(scmp(tmp,groupname)==0){ ok=group_line_has_user(line,username); free(tmp); break; } free(tmp); }
    free(line); fclose(f); return ok;
}

int user_in_groupgid(const char *username, gid_t gid){
    FILE *f=fopen(path_group(),"r"); if(!f) return 0; char *line=NULL; size_t cap=0; int ok=0;
    while(getline(&line,&cap,f)>=0){ trim(line); if(!line[0]) continue; char *tmp=xstrdup(line);
        char *p=strchr(tmp,':'); if(!p){ free(tmp); continue; } p=strchr(p+1,':'); if(!p){ free(tmp); continue; } p++; char *end=strchr(p,':'); if(end) *end=0;
        int good=0; long gv=parse_long(p,&good); if(good && (gid_t)gv==gid){ ok=user_in_groupname(username, strtok(tmp,":")); free(tmp); break; } free(tmp); }
    free(line); fclose(f); return ok;
}
