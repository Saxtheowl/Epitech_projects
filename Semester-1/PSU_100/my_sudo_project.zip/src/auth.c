
#define _XOPEN_SOURCE
#include <unistd.h>
#include <crypt.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "my_sudo.h"

static int read_shadow_hash(const char *username, char *out, size_t outsz){
    FILE *f=fopen(path_shadow(),"r"); if(!f){ puterr("my_sudo: cannot open /etc/shadow\n"); return -1; }
    char *line=NULL; size_t cap=0; int rc=-1;
    while(getline(&line,&cap,f)>=0){ char *t=trim(line); if(!t[0]) continue;
        char *c=strchr(t,':'); if(!c) continue; *c=0; if(scmp(t,username)==0){
            char *hash=c+1; char *end=strchr(hash,':'); if(end) *end=0;
            if(slen(hash)>=outsz){ puterr("my_sudo: hash too long\n"); rc=-1; break; }
            strcpy(out,hash); rc=0; break; } }
    free(line); fclose(f); if(rc!=0) puterr("my_sudo: user not found in shadow\n"); return rc;
}

int authenticate_user(const char *username, int *failed_attempts){
    char hash[256]={0}; if(read_shadow_hash(username,hash,sizeof(hash))!=0) return -1;
    int attempts=0;
    for(int i=0;i<3;i++){
        putstr("[my_sudo] password for "); putstr(username); putstr(":\n");
        char *line=NULL; size_t cap=0; ssize_t r=getline(&line,&cap,stdin); if(r<0){ free(line); return -1; }
        if(r>0 && (line[r-1]=='\n'||line[r-1]=='\r')) line[--r]=0;
        char *res=crypt(line,hash); memset(line,0,(size_t)r); free(line);
        if(res && scmp(res,hash)==0){ if(failed_attempts) *failed_attempts=attempts; char num[32]; snprintf(num,sizeof(num),"%d",attempts);
            putstr("[my_sudo] "); putstr(num); putstr(" unsuccessful attempt(s)\n"); return 0; }
        attempts++;
    } return -1;
}
