
#include <stdlib.h>
#include "my_sudo.h"
int main(int ac, char **av){
    options_t opts; if(parse_options(ac,av,&opts)!=0) return 84;
    user_info_t invoker; if(read_current_user(&invoker)!=0) return 84;
    int rc=run_sudo(&invoker,&opts); free_user(&invoker); return rc==84?84:0;
}
