
#!/usr/bin/env python3
import os, sys, tempfile, subprocess, textwrap, time

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
BIN  = os.path.join(ROOT, "my_sudo")

def run(args, env=None, input_data=None, timeout=2):
    p = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, stdin=subprocess.PIPE, text=True, env=env)
    try:
        out, err = p.communicate(input=input_data, timeout=timeout)
    except subprocess.TimeoutExpired:
        p.kill()
        out, err = p.communicate()
    return p.returncode, out, err

def assert_true(cond, msg):
    if not cond: raise AssertionError(msg)

def write(path, content):
    with open(path, "w") as f: f.write(content)

def make_mock_env(tmp):
    env = os.environ.copy()
    env["MY_SUDO_PASSWD"] = os.path.join(tmp, "passwd")
    env["MY_SUDO_SHADOW"] = os.path.join(tmp, "shadow")
    env["MY_SUDO_GROUP"]  = os.path.join(tmp, "group")
    env["MY_SUDO_SUDOERS"]= os.path.join(tmp, "sudoers")
    return env

def t_help():
    code, out, err = run([BIN, "-h"])
    assert_true(code == 0, "help exits 0")
    assert_true("usage" in out, "prints usage")

def t_authorized_and_auth_ok_exec_true():
    with tempfile.TemporaryDirectory() as d:
        env = make_mock_env(d)
        write(env["MY_SUDO_PASSWD"], "kc:x:1000:1000::/home/kc:/bin/sh\nroot:x:0:0::/root:/bin/sh\n")
        import crypt; hash = crypt.crypt("secret", crypt.mksalt(crypt.METHOD_SHA512))
        write(env["MY_SUDO_SHADOW"], f"kc:{hash}:20000:0:99999:7:::\nroot:*:20000:0:99999:7:::\n")
        write(env["MY_SUDO_GROUP"], "wheel:x:10:kc\n")
        write(env["MY_SUDO_SUDOERS"], "kc ALL=(ALL) ALL\n")
        code, out, err = run([BIN, "/usr/bin/true"], env=env, input_data="secret\n")
        assert_true(code == 0, f"authorized+auth ok -> 0, got {code} (err: {err})")
        assert_true("[my_sudo]" in out, "prompt present")

def t_unauthorized():
    with tempfile.TemporaryDirectory() as d:
        env = make_mock_env(d)
        write(env["MY_SUDO_PASSWD"], "tutu:x:1002:1002::/home/tutu:/bin/sh\n")
        import crypt; hash = crypt.crypt("pw", crypt.mksalt(crypt.METHOD_SHA512))
        write(env["MY_SUDO_SHADOW"], f"tutu:{hash}:20000:0:99999:7:::\n")
        write(env["MY_SUDO_GROUP"], "")
        write(env["MY_SUDO_SUDOERS"], "kc ALL=(ALL) ALL\n")
        code, out, err = run([BIN, "/usr/bin/true"], env=env, input_data="pw\n")
        assert_true(code == 84, "unauthorized -> 84")
        assert_true("my_sudoers" in err, "error mentions sudoers")

def t_bad_password():
    with tempfile.TemporaryDirectory() as d:
        env = make_mock_env(d)
        write(env["MY_SUDO_PASSWD"], "kc:x:1000:1000::/home/kc:/bin/sh\nroot:x:0:0::/root:/bin/sh\n")
        import crypt; hash = crypt.crypt("secret", crypt.mksalt(crypt.METHOD_SHA512))
        write(env["MY_SUDO_SHADOW"], f"kc:{hash}:20000:0:99999:7:::\n")
        write(env["MY_SUDO_GROUP"], "wheel:x:10:kc\n")
        write(env["MY_SUDO_SUDOERS"], "kc ALL=(ALL) ALL\n")
        code, out, err = run([BIN, "/usr/bin/true"], env=env, input_data="wrong\nwrong\nwrong\n")
        assert_true(code == 84, "bad password -> 84")

def main():
    cases = [
        ("help", t_help),
        ("authorized + auth ok -> exec true", t_authorized_and_auth_ok_exec_true),
        ("unauthorized", t_unauthorized),
        ("bad password", t_bad_password),
    ]
    ok = 0
    print("Running tests...")
    for name, fn in cases:
        try:
            fn()
            print("[OK]", name)
            ok += 1
        except AssertionError as e:
            print("[KO]", name, "-", e)
        except Exception as e:
            print("[KO]", name, "- unexpected:", e)
    total = len(cases)
    print(f"\nResult: {ok}/{total} tests passed.")
    sys.exit(0 if ok == total else 84)

if __name__ == "__main__":
    main()
