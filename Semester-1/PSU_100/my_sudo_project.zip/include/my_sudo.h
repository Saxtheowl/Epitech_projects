
/*
** EPITECH PROJECT, 2025
** my_sudo
** File description:
** Public header
*/

#ifndef MY_SUDO_H_
#define MY_SUDO_H_

#include <stdbool.h>
#include <stddef.h>
#include <sys/types.h>

typedef struct { char *username; uid_t uid; gid_t gid; } user_info_t;

typedef struct {
    char *target_user;
    char *target_group;
    bool keep_env;
    bool shell_mode;
    char **cmdv;
} options_t;

const char *path_passwd(void);
const char *path_shadow(void);
const char *path_group(void);
const char *path_sudoers(void);

void putstr(const char *s);
void puterr(const char *s);
size_t slen(const char *s);
int scmp(const char *a, const char *b);
char *xstrdup(const char *s);
void *xmalloc(size_t n);
char *trim(char *s);
long parse_long(const char *s, int *ok);

int read_current_user(user_info_t *out);
int read_user_by_name(const char *name, user_info_t *out);
int read_user_by_uid(uid_t uid, user_info_t *out);
int resolve_group(const char *name_or_num, gid_t *out_gid);
int resolve_user(const char *name_or_num, user_info_t *out);
int user_in_groupname(const char *username, const char *groupname);
int user_in_groupgid(const char *username, gid_t gid);

int is_authorized_in_sudoers(const user_info_t *u);
int authenticate_user(const char *username, int *failed_attempts);
int parse_options(int ac, char **av, options_t *opts);
int run_sudo(const user_info_t *invoker, const options_t *opts);
void free_user(user_info_t *u);

#endif /* !MY_SUDO_H_ */
