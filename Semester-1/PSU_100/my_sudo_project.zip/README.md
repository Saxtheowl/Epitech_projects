
# my_sudo

Implémentation simplifiée de `sudo`, conforme au sujet : parsing minimal de `/etc/sudoers`, authentification via `/etc/shadow` + `crypt()`, options `-u`, `-g`, `-E`, `-s`, exécution via `execvp()`. Erreurs sur `stderr`, **exit 84** en cas d’erreur. Aucune fonction interdite utilisée (pas de getpw*, *getsp*, getgr*, fork/clone/openat*).

## Build
make

## Usage
./my_sudo -h
./my_sudo [-ugEs] [command [args ...]]

## Tests
Tester avec des fichiers mock en définissant :
- MY_SUDO_PASSWD
- MY_SUDO_SHADOW
- MY_SUDO_GROUP
- MY_SUDO_SUDOERS
