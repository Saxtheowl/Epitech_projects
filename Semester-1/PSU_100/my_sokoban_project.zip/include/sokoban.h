
/*
** EPITECH PROJECT, 2025
** my_sokoban
** File description:
** Public header
*/

#ifndef SOKOBAN_H_
#define SOKOBAN_H_

#include <stdbool.h>
#include <stddef.h>

/* Allowed map chars */
#define C_WALL   '#'
#define C_BOX    'X'
#define C_GOAL   'O'
#define C_PLAYER 'P'
#define C_EMPTY  ' '

typedef struct {
    int w;
    int h;
    char *grid;     /* current map characters per cell (size w*h) */
    char *initial;  /* initial map to reset (size w*h) */
    char *goals;    /* boolean map (0/1) marking goal locations (size w*h) */
    int boxes_total;
    int boxes_on_goals;
    int player_x;
    int player_y;
} board_t;

/* ===== Parsing & validation ===== */
int load_map_from_file(const char *path, board_t *out);
void free_board(board_t *b);

/* ===== Game logic (independent from ncurses) ===== */
int is_victory(const board_t *b);      /* 1 if all boxes on goals */
int is_defeat(const board_t *b);       /* 1 if no box can move */
void reset_board(board_t *b);
int move_player(board_t *b, int dx, int dy); /* returns 1 if moved, 0 otherwise */

/* ===== I/O utils ===== */
void putstr(const char *s);     /* stdout */
void puterr(const char *s);     /* stderr */
int  my_getline(char **line, size_t *cap, FILE *f); /* wrap getline */
size_t slen(const char *s);

/* ===== UI loop (ncurses) ===== */
int run_game(board_t *b);

#endif /* !SOKOBAN_H_ */
