
/*
** EPITECH PROJECT, 2025
** my_sokoban
** File description:
** Load & validate map file
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "sokoban.h"

static void *xmalloc(size_t n){ void *p = malloc(n); if(!p){ puterr("my_sokoban: malloc failed\n"); exit(84);} return p; }

static int is_valid_char(int ch){
    return ch==C_WALL || ch==C_BOX || ch==C_GOAL || ch==C_PLAYER || ch==C_EMPTY;
}

static int max_int(int a,int b){ return a>b?a:b; }

static void board_zero(board_t *b){
    memset(b, 0, sizeof(*b));
    b->player_x = -1; b->player_y = -1;
}

static int validate_closed(const char * const *lines, int nlines){
    if(nlines<=0) return -1;
    int w = (int)slen(lines[0]);
    /* top row all walls (ignoring trailing spaces) */
    for(int x=0;x<w;x++){ if(lines[0][x] != C_WALL) return -1; }
    /* bottom row */
    int wb = (int)slen(lines[nlines-1]);
    for(int x=0;x<wb;x++){ if(lines[nlines-1][x] != C_WALL) return -1; }
    /* each row: first and last non-space char should be wall if present */
    for(int y=1;y<nlines-1;y++){
        const char *row = lines[y];
        int L = (int)slen(row);
        if(L==0) return -1;
        int left=0; while(left<L && row[left]==C_EMPTY) left++;
        int right=L-1; while(right>=0 && row[right]==C_EMPTY) right--;
        if(left<=right){ if(row[left]!=C_WALL || row[right]!=C_WALL) return -1; }
    }
    return 0;
}

int load_map_from_file(const char *path, board_t *out){
    FILE *f = fopen(path, "r");
    if(!f){ puterr("my_sokoban: cannot open map\n"); return -1; }
    char **lines = NULL; int n=0, cap=0;
    char *line=NULL; size_t lcap=0;
    int wmax=0;
    while(1){
        int r = my_getline(&line, &lcap, f);
        if(r<0) break;
        /* trim newline only */
        if(r>0 && line[r-1]=='\n'){ line[r-1]=0; r--; }
        if(cap==n){ int ncap = cap?cap*2:16; char **nl = realloc(lines, ncap*sizeof(char*)); if(!nl){ fclose(f); free(line); free(lines); puterr("my_sokoban: OOM\n"); return -1; } lines = nl; cap=ncap; }
        lines[n++] = strdup(line);
        wmax = max_int(wmax, r);
    }
    fclose(f); free(line);
    if(n==0){ puterr("my_sokoban: empty map\n"); for(int i=0;i<n;i++) free(lines[i]); free(lines); return -1; }
    /* validate chars, count entities */
    int cntP=0, cntX=0, cntO=0;
    for(int y=0;y<n;y++){
        for(int x=0;x<(int)slen(lines[y]);x++){
            int ch = lines[y][x];
            if(ch=='\t'){ puterr("my_sokoban: invalid char\n"); goto fail; }
            if(!is_valid_char(ch) && ch!='\r'){ puterr("my_sokoban: invalid char\n"); goto fail; }
            if(ch==C_PLAYER) cntP++;
            else if(ch==C_BOX) cntX++;
            else if(ch==C_GOAL) cntO++;
        }
    }
    if(cntP!=1 || cntX<1 || cntO<1){ puterr("my_sokoban: invalid entity counts\n"); goto fail; }
    if(validate_closed((const char * const *)lines, n)!=0){ puterr("my_sokoban: map not closed by walls\n"); goto fail; }

    board_zero(out);
    out->w = wmax;
    out->h = n;
    out->grid   = xmalloc((size_t)wmax * (size_t)n);
    out->initial= xmalloc((size_t)wmax * (size_t)n);
    out->goals  = xmalloc((size_t)wmax * (size_t)n);
    memset(out->grid, C_EMPTY, (size_t)wmax*n);
    memset(out->initial, C_EMPTY, (size_t)wmax*n);
    memset(out->goals, 0, (size_t)wmax*n);

    for(int y=0;y<n;y++){
        int L = (int)slen(lines[y]);
        for(int x=0;x<wmax;x++){
            char ch = (x<L)? lines[y][x] : C_EMPTY;
            if(ch==C_GOAL){ out->goals[y*wmax+x] = 1; ch = C_EMPTY; }
            if(ch==C_PLAYER){ out->player_x = x; out->player_y = y; ch = C_EMPTY; }
            out->grid[y*wmax+x] = ch;
            out->initial[y*wmax+x] = ch;
            if(out->goals[y*wmax+x] && ch==C_BOX) out->boxes_on_goals++;
            if(ch==C_BOX) out->boxes_total++;
        }
        free(lines[y]);
    }
    free(lines);

    if(out->player_x<0 || out->player_y<0){ puterr("my_sokoban: no player\n"); free_board(out); return -1; }
    return 0;

fail:
    for(int i=0;i<n;i++) free(lines[i]);
    free(lines);
    return -1;
}

void free_board(board_t *b){
    if(!b) return;
    free(b->grid); free(b->initial); free(b->goals);
    memset(b, 0, sizeof(*b));
}
