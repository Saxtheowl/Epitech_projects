
/*
** EPITECH PROJECT, 2025
** my_sokoban
** File description:
** Small I/O helpers
*/
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include "sokoban.h"

size_t slen(const char *s){ size_t n=0; if(!s) return 0; while(s[n]) n++; return n; }
void putstr(const char *s){ if(!s) return; write(1, s, slen(s)); }
void puterr(const char *s){ if(!s) return; write(2, s, slen(s)); }

int my_getline(char **line, size_t *cap, FILE *f){
    return (int)getline(line, cap, f);
}
