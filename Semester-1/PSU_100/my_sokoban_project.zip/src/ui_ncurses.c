
/*
** EPITECH PROJECT, 2025
** my_sokoban
** File description:
** Ncurses UI loop & rendering
*/
#include <curses.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include "sokoban.h"

static inline int idx(const board_t *b, int x, int y){ return y*b->w + x; }

static void draw_centered(const char *msg){
    int H, W; getmaxyx(stdscr, H, W);
    int y = H/2;
    int x = (W - (int)slen(msg))/2;
    if(x<0) x = 0;
    mvaddnstr(y, x, msg, W>0?W:0);
}

static void render(const board_t *b){
    erase();
    int H, W; getmaxyx(stdscr, H, W);
    if(W < b->w || H < b->h){
        draw_centered("Please enlarge the terminal");
        refresh();
        return;
    }
    int offx = (W - b->w)/2;
    int offy = (H - b->h)/2;
    for(int y=0;y<b->h;y++){
        for(int x=0;x<b->w;x++){
            char ch = b->grid[idx(b,x,y)];
            int is_goal = b->goals[idx(b,x,y)];
            if(x==b->player_x && y==b->player_y) {
                mvaddch(offy+y, offx+x, C_PLAYER);
            } else if(ch==C_BOX){
                if(is_goal) mvaddch(offy+y, offx+x, 'X'); /* still X on goal per subject */
                else mvaddch(offy+y, offx+x, 'X');
            } else if(is_goal){
                mvaddch(offy+y, offx+x, 'O');
            } else if(ch==C_WALL){
                mvaddch(offy+y, offx+x, '#');
            } else {
                mvaddch(offy+y, offx+x, ' ');
            }
        }
    }
    refresh();
}

int run_game(board_t *b){
    initscr();
    keypad(stdscr, TRUE);
    noecho();
    cbreak();
    nodelay(stdscr, FALSE);
    curs_set(0);

    int ch;
    while(1){
        render(b);
        if(is_victory(b)){
            endwin();
            return 0;
        }
        if(is_defeat(b)){
            endwin();
            return 1;
        }
        ch = getch();
        if(ch == ' '){
            reset_board(b);
            continue;
        }
        if(ch == KEY_LEFT)  move_player(b, -1,  0);
        else if(ch == KEY_RIGHT) move_player(b,  1,  0);
        else if(ch == KEY_UP)    move_player(b,  0, -1);
        else if(ch == KEY_DOWN)  move_player(b,  0,  1);
        else if(ch == 'q' || ch == 'Q'){
            endwin();
            return 1; /* consider as not solved */
        }
    }
}
