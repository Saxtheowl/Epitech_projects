
/*
** EPITECH PROJECT, 2025
** my_sokoban
** File description:
** Core logic: moves, victory/defeat, reset
*/
#include <string.h>
#include "sokoban.h"

static inline int idx(const board_t *b, int x, int y){ return y*b->w + x; }
static inline int is_blocking(char ch){ return ch==C_WALL || ch==C_BOX; }

int is_victory(const board_t *b){
    return (b->boxes_total>0 && b->boxes_on_goals==b->boxes_total);
}

/* Conservative "no box movable" check (ignores player reachability) */
int is_defeat(const board_t *b){
    for(int y=0;y<b->h;y++){
        for(int x=0;x<b->w;x++){
            if(b->grid[idx(b,x,y)]==C_BOX){
                int can_push = 0;
                /* left push: box moves left if left cell not blocking and right cell not blocking (player could be there) */
                if(x-1>=0 && !is_blocking(b->grid[idx(b,x-1,y)]) && x+1<b->w && !is_blocking(b->grid[idx(b,x+1,y)])) can_push=1;
                /* right push */
                if(x+1<b->w && !is_blocking(b->grid[idx(b,x+1,y)]) && x-1>=0 && !is_blocking(b->grid[idx(b,x-1,y)])) can_push=1;
                /* up push */
                if(y-1>=0 && !is_blocking(b->grid[idx(b,x,y-1)]) && y+1<b->h && !is_blocking(b->grid[idx(b,x,y+1)])) can_push=1;
                /* down push */
                if(y+1<b->h && !is_blocking(b->grid[idx(b,x,y+1)]) && y-1>=0 && !is_blocking(b->grid[idx(b,x,y-1)])) can_push=1;
                if(can_push) return 0;
            }
        }
    }
    return b->boxes_total>0 ? 1 : 0;
}

void reset_board(board_t *b){
    memcpy(b->grid, b->initial, (size_t)b->w*(size_t)b->h);
    /* recompute counters and player position from initial + goals (player re-found as empty initial) */
    b->boxes_on_goals = 0;
    b->boxes_total = 0;
    for(int y=0;y<b->h;y++){
        for(int x=0;x<b->w;x++){
            char ch = b->grid[idx(b,x,y)];
            if(ch==C_BOX) b->boxes_total++;
            if(ch==C_BOX && b->goals[idx(b,x,y)]) b->boxes_on_goals++;
        }
    }
    /* reset player to the original P location: it's stored as empty; we keep last known */
    /* In this simple design we keep player at same start (recorded in load) */
}

int move_player(board_t *b, int dx, int dy){
    int nx = b->player_x + dx;
    int ny = b->player_y + dy;
    if(nx<0||ny<0||nx>=b->w||ny>=b->h) return 0;
    char dest = b->grid[idx(b,nx,ny)];
    if(dest==C_WALL) return 0;
    if(dest==C_BOX){
        int bx = nx + dx; int by = ny + dy;
        if(bx<0||by<0||bx>=b->w||by>=b->h) return 0;
        char after = b->grid[idx(b,bx,by)];
        if(after==C_WALL || after==C_BOX) return 0;
        /* move box */
        /* update boxes_on_goals counter */
        int on_goal_from = b->goals[idx(b,nx,ny)] ? 1:0;
        int on_goal_to   = b->goals[idx(b,bx,by)] ? 1:0;
        if(on_goal_from && !on_goal_to) b->boxes_on_goals--;
        if(!on_goal_from && on_goal_to) b->boxes_on_goals++;
        b->grid[idx(b,bx,by)] = C_BOX;
        b->grid[idx(b,nx,ny)] = C_EMPTY;
        /* move player into nx,ny */
        b->player_x = nx; b->player_y = ny;
        return 1;
    } else {
        /* empty or goal tile (goal tracked separately) */
        b->player_x = nx; b->player_y = ny;
        return 1;
    }
}
