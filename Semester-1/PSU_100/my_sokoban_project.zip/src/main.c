
/*
** EPITECH PROJECT, 2025
** my_sokoban
** File description:
** Entry point & CLI
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "sokoban.h"

static void print_help(void){
    putstr("USAGE\n\n");
    putstr("./my_sokoban map\n");
    putstr("DESCRIPTION\n\n");
    putstr("map file representing the warehouse map, containing '#', 'P', 'X', 'O' and spaces.\n");
}

int main(int ac, char **av){
    if(ac==2 && strcmp(av[1], "-h")==0){
        print_help();
        return 0;
    }
    if(ac!=2){
        puterr("my_sokoban: bad arguments\n");
        return 84;
    }
    board_t b;
    if(load_map_from_file(av[1], &b)!=0){
        return 84;
    }
    int code = run_game(&b);
    free_board(&b);
    return code;
}
