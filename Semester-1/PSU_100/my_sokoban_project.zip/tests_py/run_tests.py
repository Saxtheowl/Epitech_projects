
#!/usr/bin/env python3
# EPITECH PROJECT, 2025
# my_sokoban - stdlib tests
import os, sys, tempfile, subprocess, time, signal, textwrap, shutil, json, re

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
BIN  = os.path.join(ROOT, "my_sokoban")

def run(args, timeout=2):
    p = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, stdin=subprocess.PIPE, text=True)
    try:
        out, err = p.communicate(timeout=timeout)
    except subprocess.TimeoutExpired:
        p.kill()
        out, err = p.communicate()
    return p.returncode, out, err

def write_map(path, content):
    with open(path, "w") as f:
        f.write(content)

def assert_true(cond, msg):
    if not cond:
        raise AssertionError(msg)

def t_help_ok():
    code, out, err = run([BIN, "-h"])
    assert_true(code == 0, "help exits 0")
    assert_true("USAGE" in out, "help shows USAGE")

def t_bad_args_and_invalid_map():
    code, out, err = run([BIN])
    assert_true(code == 84, "no arg -> 84")
    with tempfile.TemporaryDirectory() as d:
        mp = os.path.join(d, "m.txt")
        write_map(mp, "####\n#P #\n#  #\n# X \n####\n") # not closed last row
        code, out, err = run([BIN, mp])
        assert_true(code == 84, "invalid map -> 84")

def t_valid_map_starts():
    with tempfile.TemporaryDirectory() as d:
        mp = os.path.join(d, "m.txt")
        write_map(mp, "##########\n#   O    #\n#   X    #\n#   P    #\n##########\n")
        # Launch and immediately send 'q' to exit
        p = subprocess.Popen([BIN, mp], stdout=subprocess.PIPE, stderr=subprocess.PIPE, stdin=subprocess.PIPE, text=True)
        time.sleep(0.3)
        try:
            p.stdin.write("q"); p.stdin.flush()
        except Exception:
            pass
        code = p.wait(timeout=2)
        assert_true(code in (0,1), "game loop starts and exits 0/1")

def main():
    cases = [
        ("help ok", t_help_ok),
        ("bad args & invalid map", t_bad_args_and_invalid_map),
        ("valid map starts", t_valid_map_starts),
    ]
    ok = 0
    print("Running tests...")
    for name, fn in cases:
        try:
            fn()
            print("[OK]", name)
            ok += 1
        except AssertionError as e:
            print("[KO]", name, "-", e)
        except Exception as e:
            print("[KO]", name, "- unexpected:", e)
    total = len(cases)
    print(f"\nResult: {ok}/{total} tests passed.")
    sys.exit(0 if ok == total else 84)

if __name__ == "__main__":
    main()
