
# my_sokoban

Reproduction terminale de **Sokoban** avec **ncurses**.  
- Touches : flèches pour se déplacer, **ESPACE** pour réinitialiser la partie, **Q** pour quitter.  
- Redimensionnement : tant que le terminal est trop petit, un message centré demande d'agrandir.  
- **Sorties & codes** : erreurs sur `stderr` + **exit 84** ; fin de partie : **0** si toutes les caisses sont sur les `O`, **1** si plus aucune caisse n'est déplaçable.  
- Aucun **bonus** implémenté.

## Build
```bash
make
```

## Usage
```bash
./my_sokoban -h
./my_sokoban path/to/map.txt
```

## Format de carte
Caractères autorisés : espace, `#`, `X`, `O`, `P`, et `\n` (fin de ligne).  
La carte n'est pas forcément carrée, mais doit être **fermée par des murs**.  
- Un seul `P` (joueur)  
- Au moins un `X` (caisse) et un `O` (objectif)  
- Les objectifs sont affichés même sans caisse ; une caisse sur un objectif reste `X`.

## Tests
`make tests_run` lance un runner **Python stdlib** qui vérifie :  
- `-h` et codes de sortie,  
- validation de cartes (OK/KO),  
- logique de base (victoire/défaite/mouvements) via fonctions isolées.

> Remarque : le cœur de la logique (mouvements, victoire/défaite, reset) est isolé de l’UI `ncurses` pour faciliter les tests.

